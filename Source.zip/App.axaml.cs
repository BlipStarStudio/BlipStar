using Avalonia;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Markup.Xaml;
using Launcher.Core;

namespace Launcher.App;

public partial class App : Application
{
    public override void Initialize()
    {
        AvaloniaXamlLoader.Load(this);
    }

    public override void OnFrameworkInitializationCompleted()
    {
        if (ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop)
        {
            // Инициализируем наши сервисы
            IGameLauncher gameLauncher = new CmlGameLauncher();
            ISettingsService settingsService = new JsonSettingsService();
            
            // Создаем ViewModel и передаем ей зависимости
            var vm = new MainViewModel(gameLauncher, settingsService);
            
            // Создаем главное окно и передаем ему ViewModel
            desktop.MainWindow = new MainWindow(vm);

            // ОЧЕНЬ ВАЖНО: при закрытии окна вызываем Shutdown, 
            // чтобы лаунчер отключился от Discord и убрал статус
            desktop.ShutdownRequested += (s, e) => vm.Shutdown();
        }

        base.OnFrameworkInitializationCompleted();
    }
}