using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using CmlLib.Core;
using CmlLib.Core.Auth;
using CmlLib.Core.ProcessBuilder;

namespace Launcher.Core;

public sealed class CmlGameLauncher : IGameLauncher
{
    public async Task LaunchAsync(Profile profile, IProgress<LaunchProgress> progress, CancellationToken ct)
    {
        string gameDirectory = Path.GetFullPath(string.IsNullOrWhiteSpace(profile.GameDirectory) 
            ? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), ".minecraft") 
            : profile.GameDirectory);
            
        Directory.CreateDirectory(gameDirectory);

        var minecraftPath = new MinecraftPath(gameDirectory);
        var launcher = new MinecraftLauncher(minecraftPath);

        progress.Report(new LaunchProgress("Подготовка Minecraft", 0));
        await launcher.InstallAsync(profile.Version, cancellationToken: ct);
        progress.Report(new LaunchProgress("Подготовка процесса игры", 95));

        var options = new MLaunchOption
        {
            Session = MSession.CreateOfflineSession(string.IsNullOrWhiteSpace(profile.Name) ? "Player" : profile.Name),
            MaximumRamMb = 4096
        };

        if (!string.IsNullOrWhiteSpace(profile.JavaPath)) options.JavaPath = profile.JavaPath;

        var process = await launcher.CreateProcessAsync(profile.Version, options);
        progress.Report(new LaunchProgress("Запуск Minecraft", 100));
        process.Start();
    }

    public Task<List<string>> GetInstalledVersionsAsync(string gameDirectory)
    {
        string versionsDirectory = Path.Combine(gameDirectory, "versions");
        if (!Directory.Exists(versionsDirectory)) return Task.FromResult(new List<string>());

        List<string> versions = Directory
            .EnumerateDirectories(versionsDirectory)
            .Select(Path.GetFileName)
            .Where(name => !string.IsNullOrWhiteSpace(name))
            .Select(name => name!)
            .OrderByDescending(name => name)
            .ToList();

        return Task.FromResult(versions);
    }

    public async Task<List<string>> GetAllVersionsAsync()
    {
        var launcher = new MinecraftLauncher();
        var versions = await launcher.GetAllVersionsAsync();
        return versions.Select(v => v.Name).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
    }

    public async Task InstallVersionAsync(string version, string gameDirectory, CancellationToken ct = default)
    {
        Directory.CreateDirectory(gameDirectory);
        var minecraftPath = new MinecraftPath(gameDirectory);
        var launcher = new MinecraftLauncher(minecraftPath);
        await launcher.InstallAsync(version);
    }
}