namespace Launcher.Core;

public interface ISettingsService
{
    Task<Profile> LoadProfileAsync(CancellationToken ct = default);
    Task SaveProfileAsync(Profile profile, CancellationToken ct = default);
}