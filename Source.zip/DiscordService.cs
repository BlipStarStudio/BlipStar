using System;
using System.IO;
using System.IO.Pipes;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Launcher.App;

public class DiscordService : IDisposable
{
    private readonly string _appId = "1561432580761321542";
    private NamedPipeClientStream? _pipe;
    private readonly string _pipeName;
    private bool _isConnected;

    public DiscordService()
    {
        _pipeName = @"discord-ipc-0";
        _ = ConnectAsync();
    }

    private async Task ConnectAsync()
    {
        try
        {
            _pipe = new NamedPipeClientStream(".", _pipeName, PipeDirection.InOut, PipeOptions.Asynchronous);
            await _pipe.ConnectAsync(3000);
            _isConnected = true;

            var handshake = new
            {
                v = 1,
                client_id = _appId
            };
            await SendPayloadAsync(0, handshake);
            
            Console.WriteLine("Discord RPC: Успешно подключен!");
        }
        catch (Exception)
        {
            _isConnected = false;
            Console.WriteLine("Discord RPC: Discord не запущен или недоступен.");
        }
    }

    public void SetMenuState()
    {
        if (!_isConnected) return;
        _ = UpdatePresenceAsync("В главном меню", "Выбирает сборку", "logo", "BlipStar Launcher", null, null);
    }

    public void SetGameState(string version)
    {
        if (!_isConnected) return;
        _ = UpdatePresenceAsync("Играет в Minecraft", $"Версия: {version}", "logo", "BlipStar Launcher", "play", "В игре");
    }

    private async Task UpdatePresenceAsync(string details, string state, string largeImg, string largeText, string? smallImg, string? smallText)
    {
        if (!_isConnected || _pipe == null) return;

        try
        {
            long startTime = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();

            var activity = new
            {
                details = details,
                state = state,
                timestamps = new { start = startTime },
                assets = new
                {
                    large_image = largeImg,
                    large_text = largeText,
                    small_image = smallImg,
                    small_text = smallText
                },
                instance = false
            };

            var payload = new
            {
                cmd = "SET_ACTIVITY",
                args = new
                {
                    pid = Environment.ProcessId,
                    activity = activity
                },
                nonce = Guid.NewGuid().ToString()
            };

            await SendPayloadAsync(1, payload);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Discord RPC Error: {ex.Message}");
            _isConnected = false;
        }
    }

    private async Task SendPayloadAsync(int opcode, object data)
    {
        if (_pipe == null || !_pipe.IsConnected) return;

        string json = JsonSerializer.Serialize(data);
        byte[] jsonBytes = Encoding.UTF8.GetBytes(json);

        byte[] buffer = new byte[8 + jsonBytes.Length];

        BitConverter.GetBytes(opcode).CopyTo(buffer, 0);
        BitConverter.GetBytes(jsonBytes.Length).CopyTo(buffer, 4);
        jsonBytes.CopyTo(buffer, 8);

        await _pipe.WriteAsync(buffer, 0, buffer.Length);
        await _pipe.FlushAsync();
    }

    public void Dispose()
    {
        _pipe?.Dispose();
    }
}