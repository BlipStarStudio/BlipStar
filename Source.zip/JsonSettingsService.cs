using System;
using System.IO;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace Launcher.Core;

public sealed class JsonSettingsService : ISettingsService
{
    private readonly string _settingsPath;

    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true };

    public JsonSettingsService()
    {
        string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
        string directory = Path.Combine(appData, "BlipStar");
        Directory.CreateDirectory(directory);
        _settingsPath = Path.Combine(directory, "settings.json");
    }

    public async Task<Profile> LoadProfileAsync(CancellationToken ct = default)
    {
        if (!File.Exists(_settingsPath)) return new Profile();

        await using var stream = new FileStream(_settingsPath, FileMode.Open, FileAccess.Read, FileShare.Read);
        var settings = await JsonSerializer.DeserializeAsync<Settings>(stream, JsonOptions, ct);
        return settings?.Profile ?? new Profile();
    }

    public async Task SaveProfileAsync(Profile profile, CancellationToken ct = default)
    {
        var settings = new Settings { Profile = profile };
        await using var stream = new FileStream(_settingsPath, FileMode.Create, FileAccess.Write, FileShare.None);
        await JsonSerializer.SerializeAsync(stream, settings, JsonOptions, ct);
    }
}