using System;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Launcher.Core;

namespace Launcher.App;

public partial class SettingsViewModel : ObservableObject
{
    private readonly Profile _profile;
    public Action? CloseAction { get; set; }

    [ObservableProperty] private string gameDirectory = string.Empty;
    [ObservableProperty] private int ramGb;
    [ObservableProperty] private string javaPath = string.Empty;
    [ObservableProperty] private bool discordRpcEnabled;

    public SettingsViewModel(Profile profile)
    {
        _profile = profile;
        GameDirectory = profile.GameDirectory;
        JavaPath = profile.JavaPath;
        RamGb = 4; // Значение по умолчанию
        DiscordRpcEnabled = true;
    }

    [RelayCommand]
    private void Save()
    {
        _profile.GameDirectory = GameDirectory;
        _profile.JavaPath = JavaPath;
        
        CloseAction?.Invoke();
    }

    [RelayCommand]
    private void Cancel()
    {
        CloseAction?.Invoke();
    }
}