using Avalonia.Controls;
using Avalonia.Platform.Storage;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Launcher.App;

public partial class MainWindow : Window
{
    public MainWindow(MainViewModel viewModel)
    {
        InitializeComponent();
        DataContext = viewModel;
        viewModel.FolderPicker = SelectFolderAsync;
        
        // Вот эта строчка связывает кнопку в лаунчере с открытием окна настроек
        viewModel.OpenSettingsAction = ShowSettings;
    }

    private void ShowSettings()
    {
        if (DataContext is MainViewModel vm && vm.SelectedProfile != null)
        {
            var settingsVm = new SettingsViewModel(vm.SelectedProfile);
            var settingsWindow = new SettingsWindow(settingsVm);
            settingsWindow.ShowDialog(this);
        }
    }

    private async Task<string?> SelectFolderAsync()
    {
        IReadOnlyList<IStorageFolder> folders = await StorageProvider.OpenFolderPickerAsync(
            new FolderPickerOpenOptions { Title = "Выберите папку Minecraft", AllowMultiple = false });

        if (folders.Count == 0) return null;
        return folders[0].TryGetLocalPath();
    }
}