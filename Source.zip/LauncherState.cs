namespace Launcher.App;

public enum LauncherState
{
    Idle,
    Preparing,
    Downloading,
    Launching,
    Running,
    Error
}