namespace Launcher.Core;

public sealed record LaunchProgress(string Stage, double Percent);