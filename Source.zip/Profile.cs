using System;
using System.IO;

namespace Launcher.Core;

public sealed class Profile
{
    public string Name { get; set; } = "Player";
    public string Version { get; set; } = "1.20.4";
    public string Loader { get; set; } = "Vanilla";
    public string JavaPath { get; set; } = string.Empty;
    public string GameDirectory { get; set; } = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), ".minecraft");
    
    public int RamMb { get; set; } = 4096;
    public bool DiscordRpcEnabled { get; set; } = true;
    
    // ВОТ ЭТИ ДВЕ СТРОЧКИ:
    public bool ShowSnapshots { get; set; } = false;
    public bool ShowOldAlphaBeta { get; set; } = false;
}