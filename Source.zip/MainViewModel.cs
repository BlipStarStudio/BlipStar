using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Launcher.Core;

namespace Launcher.App;

public partial class MainViewModel : ObservableObject
{
    private readonly IGameLauncher _gameLauncher;
    private readonly ISettingsService _settingsService;
    private readonly DiscordService _discordService; // Добавили Discord

    public Func<Task<string?>>? FolderPicker { get; set; }
    public Action? OpenSettingsAction { get; set; }

    public ObservableCollection<string> AvailableVersions { get; } = new();
    public ObservableCollection<string> InstalledVersions { get; } = new();
    public ObservableCollection<Profile> Profiles { get; } = new();

    [ObservableProperty] private Profile? selectedProfile;
    [ObservableProperty] private string selectedVersion = string.Empty;
    [ObservableProperty] private string gameDirectory = string.Empty;
    [ObservableProperty] private string statusText = "Загрузка настроек...";
    [ObservableProperty] private double progress;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(PlayCommand))]
    private LauncherState state = LauncherState.Idle;

    public MainViewModel(IGameLauncher gameLauncher, ISettingsService settingsService)
    {
        _gameLauncher = gameLauncher;
        _settingsService = settingsService;
        
        // Инициализируем Discord
        _discordService = new DiscordService();
        
        _ = InitializeAsync();
    }

    private async Task InitializeAsync()
    {
        try
        {
            Profile profile = await _settingsService.LoadProfileAsync();
            Profiles.Clear();
            Profiles.Add(profile);
            SelectedProfile = profile;

            if (string.IsNullOrWhiteSpace(SelectedVersion)) SelectedVersion = profile.Version;

            StatusText = "Получение списка версий Minecraft...";
            var versions = await _gameLauncher.GetAllVersionsAsync();
            AvailableVersions.Clear();
            foreach (string version in versions) AvailableVersions.Add(version);

            await RefreshInstalledVersionsAsync();
            StatusText = "Готов к запуску";
            
            // Когда лаунчер загрузился, ставим статус "В меню"
            _discordService.SetMenuState();
        }
        catch (Exception ex)
        {
            StatusText = $"Ошибка инициализации: {ex.Message}";
        }
    }

    partial void OnSelectedProfileChanged(Profile? value)
    {
        if (value is null) return;
        SelectedVersion = value.Version;
        GameDirectory = value.GameDirectory;
    }

    partial void OnSelectedVersionChanged(string value)
    {
        if (SelectedProfile is not null) SelectedProfile.Version = value;
        PlayCommand.NotifyCanExecuteChanged();
    }

    partial void OnGameDirectoryChanged(string value)
    {
        if (SelectedProfile is not null) SelectedProfile.GameDirectory = value;
        PlayCommand.NotifyCanExecuteChanged();
    }

    [RelayCommand]
    private async Task SaveSettingsAsync()
    {
        if (SelectedProfile is null) return;
        try
        {
            SelectedProfile.Version = SelectedVersion;
            SelectedProfile.GameDirectory = GameDirectory;
            await _settingsService.SaveProfileAsync(SelectedProfile);
            StatusText = "Настройки сохранены";
        }
        catch (Exception ex) { StatusText = $"Ошибка сохранения: {ex.Message}"; }
    }

    [RelayCommand]
    private async Task DownloadVersionAsync()
    {
        if (string.IsNullOrWhiteSpace(SelectedVersion)) return;
        try
        {
            State = LauncherState.Downloading;
            Progress = 0;
            StatusText = $"Установка Minecraft {SelectedVersion}...";
            await _gameLauncher.InstallVersionAsync(SelectedVersion, GameDirectory);
            Progress = 100;
            await RefreshInstalledVersionsAsync();
            StatusText = $"Версия {SelectedVersion} установлена";
        }
        catch (Exception ex) { StatusText = $"Ошибка установки: {ex.Message}"; }
        finally { State = LauncherState.Idle; }
    }

    [RelayCommand]
    private async Task RefreshVersionsAsync()
    {
        try
        {
            StatusText = "Обновление списка версий...";
            var versions = await _gameLauncher.GetAllVersionsAsync();
            AvailableVersions.Clear();
            foreach (string version in versions) AvailableVersions.Add(version);
            await RefreshInstalledVersionsAsync();
            StatusText = $"Доступно версий: {AvailableVersions.Count}";
        }
        catch (Exception ex) { StatusText = $"Ошибка получения версий: {ex.Message}"; }
    }

    private async Task RefreshInstalledVersionsAsync()
    {
        if (string.IsNullOrWhiteSpace(GameDirectory)) return;
        var versions = await _gameLauncher.GetInstalledVersionsAsync(GameDirectory);
        InstalledVersions.Clear();
        foreach (string version in versions) InstalledVersions.Add(version);
    }

    [RelayCommand]
    private async Task SelectFolderAsync()
    {
        if (FolderPicker is null) return;
        try
        {
            string? folder = await FolderPicker();
            if (string.IsNullOrWhiteSpace(folder)) return;
            GameDirectory = folder;
            await RefreshInstalledVersionsAsync();
        }
        catch (Exception ex) { StatusText = $"Ошибка выбора папки: {ex.Message}"; }
    }

    [RelayCommand]
    private void OpenSettings()
    {
        OpenSettingsAction?.Invoke();
    }

    private bool CanPlay() => State == LauncherState.Idle && SelectedProfile is not null && !string.IsNullOrWhiteSpace(SelectedVersion) && !string.IsNullOrWhiteSpace(GameDirectory);

    [RelayCommand(CanExecute = nameof(CanPlay))]
    private async Task PlayAsync()
    {
        if (SelectedProfile is null) return;
        try
        {
            SelectedProfile.Version = SelectedVersion;
            SelectedProfile.GameDirectory = GameDirectory;

            State = LauncherState.Preparing;
            StatusText = "Подготовка к запуску...";
            Progress = 0;

            // Меняем статус в Discord на "Играет"
            _discordService.SetGameState(SelectedVersion);

            var reporter = new Progress<LaunchProgress>(update =>
            {
                StatusText = update.Stage;
                Progress = Math.Clamp(update.Percent, 0, 100);
            });

            await _gameLauncher.LaunchAsync(SelectedProfile, reporter, CancellationToken.None);
            StatusText = "Игра запущена";
            Progress = 100;
        }
        catch (Exception ex) 
        { 
            StatusText = $"Ошибка запуска: {ex.Message}";
            // Если игра не запустилась, возвращаем статус в меню
            _discordService.SetMenuState();
        }
        finally 
        { 
            State = LauncherState.Idle; 
            PlayCommand.NotifyCanExecuteChanged(); 
        }
    }

    // Этот метод вызовется, когда лаунчер закрывается
    public void Shutdown()
    {
        _discordService.Dispose();
    }
}