using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Launcher.Core;

public interface IGameLauncher
{
    Task LaunchAsync(Profile profile, IProgress<LaunchProgress> progress, CancellationToken ct);
    Task<List<string>> GetInstalledVersionsAsync(string gameDirectory);
    Task<List<string>> GetAllVersionsAsync();
    Task InstallVersionAsync(string version, string gameDirectory, CancellationToken ct = default);
}