using System;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Launcher.Core;

namespace Launcher.App;

public partial class SettingsViewModel : ObservableObject
{
    private readonly Profile _profile;
    public Action? CloseAction { get; set; }

    [ObservableProperty] private string gameDirectory = string.Empty;
    [ObservableProperty] private int ramMb = 4096;
    [ObservableProperty] private string javaPath = string.Empty;
    [ObservableProperty] private bool discordRpcEnabled = true;
    [ObservableProperty] private string statusText = string.Empty;

    public SettingsViewModel(Profile profile)
    {
        _profile = profile;
        GameDirectory = profile.GameDirectory;
        JavaPath = profile.JavaPath;
        RamMb = profile.RamMb;
        DiscordRpcEnabled = profile.DiscordRpcEnabled;
    }

    [RelayCommand]
    private void Save()
    {
        // Сохраняем данные обратно в профиль
        _profile.GameDirectory = GameDirectory;
        _profile.JavaPath = JavaPath;
        _profile.RamMb = RamMb;
        _profile.DiscordRpcEnabled = DiscordRpcEnabled;
        
        // Закрываем окно
        CloseAction?.Invoke();
    }

    [RelayCommand]
    private void Cancel()
    {
        CloseAction?.Invoke();
    }
}