namespace Launcher.Core;

public sealed class Settings
{
    public Profile Profile { get; set; } = new();
}